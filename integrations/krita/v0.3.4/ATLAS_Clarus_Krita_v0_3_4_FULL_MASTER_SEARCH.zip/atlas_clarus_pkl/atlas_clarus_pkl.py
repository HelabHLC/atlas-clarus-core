# ATLAS Clarus PKL for Krita — Engineering Beta v0.3.4
#
# DIRECT DOCUMENT PIXEL MODE:
# canvas click -> deterministic widget-to-image XY -> Document.pixelData(x,y,1,1)
# -> independent Krita real-canvas sampler cross-check -> PKL v3.4.0 lookup -> freeze
#
# Fail closed:
# - only RGBA / U8 / documented sRGB
# - direct XY requires Krita Canvas.preferredCenter()
# - direct mode currently requires unrotated + unmirrored canvas
# - raw pixel and real-canvas sampler must agree before freeze
#
# No physical measurement. No DEVICE validation. No production approval.

import json
import math
import os
import re

try:
    from PyQt5.QtCore import Qt, QObject, QEvent, QTimer
    from PyQt5.QtGui import QColor, QIcon
    from PyQt5.QtWidgets import (
        QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
        QPushButton, QListWidget, QListWidgetItem, QGroupBox, QFormLayout,
        QMessageBox, QFrame, QScrollArea
    )
    QT6 = False
except ImportError:
    from PyQt6.QtCore import Qt, QObject, QEvent, QTimer
    from PyQt6.QtGui import QColor, QIcon
    from PyQt6.QtWidgets import (
        QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
        QPushButton, QListWidget, QListWidgetItem, QGroupBox, QFormLayout,
        QMessageBox, QFrame, QScrollArea
    )
    QT6 = True

from krita import Krita, DockWidget, DockWidgetFactory, DockWidgetFactoryBase, ManagedColor

PLUGIN_VERSION = "0.3.4"
DOCKER_ID = "atlas_clarus_pkl_docker"

if QT6:
    USER_ROLE = Qt.ItemDataRole.UserRole
    LEFT_BUTTON = Qt.MouseButton.LeftButton
    MOUSE_RELEASE = QEvent.Type.MouseButtonRelease
    WA_TRANSPARENT_MOUSE = Qt.WidgetAttribute.WA_TransparentForMouseEvents
else:
    USER_ROLE = Qt.UserRole
    LEFT_BUTTON = Qt.LeftButton
    MOUSE_RELEASE = QEvent.MouseButtonRelease
    WA_TRANSPARENT_MOUSE = Qt.WA_TransparentForMouseEvents


def _parse_rgb_or_hex(text):
    s = text.strip()
    if re.fullmatch(r"#?[0-9A-Fa-f]{6}", s):
        s = s.lstrip("#")
        return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))
    m = re.fullmatch(r"\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*", s)
    if m:
        rgb = tuple(int(m.group(i)) for i in (1, 2, 3))
        if all(0 <= v <= 255 for v in rgb):
            return rgb
    raise ValueError("Enter #RRGGBB or R,G,B using documented 8-bit sRGB values.")


def _hex_for(rgb):
    return "#{:02X}{:02X}{:02X}".format(*rgb)


def _norm_u8(v):
    return int(round(max(0.0, min(1.0, float(v))) * 255.0))


def _global_pos(event):
    if hasattr(event, "globalPosition"):
        return event.globalPosition().toPoint()
    return event.globalPos()


class AtlasEngine:
    def __init__(self, payload):
        self.payload = payload
        self.rows = payload["rows"]

    def nearest_rgb(self, rgb):
        rs, gs, bs = rgb
        best = None
        best_key = None
        for row in self.rows:
            r, g, b = row["rgb"]
            d2 = (rs-r)*(rs-r) + (gs-g)*(gs-g) + (bs-b)*(bs-b)
            key = (d2, row["atlas_row_id"])
            if best_key is None or key < best_key:
                best_key = key
                best = row
        return best, best_key[0]

    def search(self, query):
        """
        Search the COMPLETE bundled PKL master.
        No 300-row UI cap. Blank query returns all rows in atlas_row_id order.
        """
        q = query.strip().lower()
        if not q:
            return self.rows

        exact_row = None
        try:
            exact_row = int(q)
        except Exception:
            pass

        out = []
        for row in self.rows:
            if (
                q in row["reference"].lower()
                or q in row["hex"].lower()
                or (exact_row is not None and row["atlas_row_id"] == exact_row)
            ):
                out.append(row)
        return out


class CanvasClickFilter(QObject):
    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner

    def eventFilter(self, obj, event):
        if self.owner._picker_armed and event.type() == MOUSE_RELEASE:
            try:
                if event.button() == LEFT_BUTTON:
                    self.owner._handle_mouse_release(obj, event)
            except Exception as e:
                self.owner._picker_fail("Canvas event error: %s" % e)
        return False


class AtlasClarusDocker(DockWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ATLAS Clarus PKL")

        self._selected = None
        self._last_input_rgb = None
        self._picker_armed = False
        self._pending_pick = None
        self._marker = None

        data_path = os.path.join(os.path.dirname(__file__), "atlas_data.json")
        with open(data_path, "r", encoding="utf-8") as f:
            self.data = json.load(f)
        self.engine = AtlasEngine(self.data)

        root = QWidget(self)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea(root)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        outer.addWidget(scroll)

        content = QWidget()
        scroll.setWidget(content)

        layout = QVBoxLayout(content)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        layout.addWidget(QLabel("<b>ATLAS Clarus PKL</b> · Engineering Beta v%s" % PLUGIN_VERSION))

        # ------------------------------------------------------
        # ALWAYS-VISIBLE SOURCE → PKL SUMMARY
        # ------------------------------------------------------
        summary_box = QGroupBox("SOURCE PIXEL  →  PKL REFERENCE")
        summary_layout = QVBoxLayout(summary_box)

        source_row = QHBoxLayout()
        self.source_swatch = QLabel()
        self.source_swatch.setFixedSize(54, 38)
        self.source_swatch.setFrameShape(QFrame.Box)

        self.source_summary = QLabel(
            "<b>SOURCE PIXEL</b><br>"
            "XY —<br>"
            "RGB —<br>"
            "HEX —"
        )
        self.source_summary.setWordWrap(True)

        source_row.addWidget(self.source_swatch)
        source_row.addWidget(self.source_summary, 1)
        summary_layout.addLayout(source_row)

        arrow = QLabel("<b>↓ deterministic v3.4.0 RGB match</b>")
        arrow.setAlignment(Qt.AlignCenter if not QT6 else Qt.AlignmentFlag.AlignCenter)
        summary_layout.addWidget(arrow)

        pkl_row = QHBoxLayout()
        self.pkl_summary_swatch = QLabel()
        self.pkl_summary_swatch.setFixedSize(54, 38)
        self.pkl_summary_swatch.setFrameShape(QFrame.Box)

        self.pkl_summary = QLabel(
            "<b>PKL REFERENCE</b><br>"
            "Reference —<br>"
            "atlas_row_id —<br>"
            "PKL RGB/HEX —<br>"
            "d²_RGB — · NOT_FROZEN"
        )
        self.pkl_summary.setWordWrap(True)

        pkl_row.addWidget(self.pkl_summary_swatch)
        pkl_row.addWidget(self.pkl_summary, 1)
        summary_layout.addLayout(pkl_row)

        self.summary_gate = QLabel("RAW/SAMPLER CROSSCHECK = —  ·  measured_qc_status = NOT_MEASURED")
        self.summary_gate.setWordWrap(True)
        summary_layout.addWidget(self.summary_gate)

        layout.addWidget(summary_box)

        self.status = QLabel(
            "Workflow v3.4.0 · RGB_ONLY_DLambda_POSTHOC · K=UNLIMITED<br>"
            "Direct document pixel mode · measured_qc_status = NOT_MEASURED"
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        layout.addWidget(sep)

        # ------------------------------------------------------
        # DIRECT XY PICKER
        # ------------------------------------------------------
        picker_box = QGroupBox("🎯 Direct Canvas Pixel → Document.pixelData")
        picker_layout = QVBoxLayout(picker_box)

        buttons = QHBoxLayout()
        self.pick_btn = QPushButton("PICK EXACT PIXEL")
        self.pick_btn.clicked.connect(self.arm_picker)
        self.cancel_btn = QPushButton("CANCEL")
        self.cancel_btn.clicked.connect(self.cancel_picker)
        self.cancel_btn.setEnabled(False)
        buttons.addWidget(self.pick_btn, 1)
        buttons.addWidget(self.cancel_btn)
        picker_layout.addLayout(buttons)

        self.picker_state = QLabel(
            "Ready. Direct freeze requires RGBA / U8 / sRGB and an unrotated, unmirrored canvas."
        )
        self.picker_state.setWordWrap(True)
        picker_layout.addWidget(self.picker_state)

        self.xy_label = QLabel("Document XY: —")
        self.xy_label.setWordWrap(True)
        picker_layout.addWidget(self.xy_label)

        self.raw_label = QLabel("Raw pixelData BGRA: —")
        self.raw_label.setWordWrap(True)
        picker_layout.addWidget(self.raw_label)

        self.crosscheck_label = QLabel("Independent sampler cross-check: —")
        self.crosscheck_label.setWordWrap(True)
        picker_layout.addWidget(self.crosscheck_label)

        picker_note = QLabel(
            "The PKL lookup is executed from Document.pixelData, not from the screen. "
            "Krita's real-canvas sampler is used only as an independent coordinate/source cross-check."
        )
        picker_note.setWordWrap(True)
        picker_layout.addWidget(picker_note)

        layout.addWidget(picker_box)

        # ------------------------------------------------------
        # Explicit RGB/HEX
        # ------------------------------------------------------
        lookup_box = QGroupBox("Deterministic 8-bit sRGB lookup")
        lookup_layout = QVBoxLayout(lookup_box)
        row = QHBoxLayout()

        self.input_edit = QLineEdit()
        self.input_edit.setPlaceholderText("#FF7A2A  or  255,122,42")

        self.match_btn = QPushButton("MATCH RGB / HEX")
        self.match_btn.clicked.connect(self.match_input)
        self.input_edit.returnPressed.connect(self.match_input)

        row.addWidget(self.input_edit, 1)
        row.addWidget(self.match_btn)
        lookup_layout.addLayout(row)
        layout.addWidget(lookup_box)

        # ------------------------------------------------------
        # Search
        # ------------------------------------------------------
        search_box = QGroupBox("Search PKL master")
        search_layout = QVBoxLayout(search_box)

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("H050_L060_C080 · row id · #EC6521")
        self.search_edit.textChanged.connect(self.refresh_search)
        search_layout.addWidget(self.search_edit)

        self.search_count_label = QLabel("Master rows: loading…")
        search_layout.addWidget(self.search_count_label)

        self.list_widget = QListWidget()
        self.list_widget.itemSelectionChanged.connect(self.search_selection_changed)
        search_layout.addWidget(self.list_widget, 1)
        layout.addWidget(search_box, 1)

        # ------------------------------------------------------
        # Reference result
        # ------------------------------------------------------
        details_box = QGroupBox("Reference result")
        form = QFormLayout(details_box)

        self.swatch = QLabel()
        self.swatch.setFixedSize(84, 56)
        self.swatch.setFrameShape(QFrame.Box)

        self.ref_label = QLabel("—")
        self.id_label = QLabel("—")
        self.src_label = QLabel("—")
        self.rgb_label = QLabel("—")
        self.hex_label = QLabel("—")
        self.d2_label = QLabel("—")
        self.lab_label = QLabel("—")
        self.dl_label = QLabel("—")
        self.oog_label = QLabel("—")
        self.profile_label = QLabel("—")
        self.freeze_label = QLabel("NOT_FROZEN")

        form.addRow("PKL swatch", self.swatch)
        form.addRow("Reference", self.ref_label)
        form.addRow("source_atlas_row_id", self.id_label)
        form.addRow("Input RGB", self.src_label)
        form.addRow("PKL RGB", self.rgb_label)
        form.addRow("PKL HEX", self.hex_label)
        form.addRow("d²_RGB", self.d2_label)
        form.addRow("Lab (master)", self.lab_label)
        form.addRow("Δλ (post-hoc)", self.dl_label)
        form.addRow("sRGB OOG pre-clip", self.oog_label)
        form.addRow("Document profile", self.profile_label)
        form.addRow("Freeze status", self.freeze_label)

        layout.addWidget(details_box)

        action_row = QHBoxLayout()
        self.use_btn = QPushButton("USE PKL COLOR")
        self.use_btn.setEnabled(False)
        self.use_btn.clicked.connect(self.use_selected_color)

        self.highlight_btn = QPushButton("HIGHLIGHT")
        self.highlight_btn.setEnabled(False)
        self.highlight_btn.clicked.connect(self.highlight_reference)

        action_row.addWidget(self.use_btn)
        action_row.addWidget(self.highlight_btn)
        layout.addLayout(action_row)

        warning = QLabel(
            "Reference identity only. Exact PKL RGB/HEX are read from the bundled hash-locked "
            "active-master extract. Digital analysis is not physical measurement or production approval."
        )
        warning.setWordWrap(True)
        layout.addWidget(warning)

        self.setWidget(root)
        self.refresh_search()

        self._click_filter = CanvasClickFilter(self)
        QApplication.instance().installEventFilter(self._click_filter)

    def canvasChanged(self, canvas):
        pass

    # ------------------------------------------------------
    # Canvas / coordinate helpers
    # ------------------------------------------------------
    def _canvas_ancestor(self, obj):
        cur = obj
        best = None
        for _ in range(18):
            if cur is None:
                break
            try:
                cls = str(cur.metaObject().className()).lower()
            except Exception:
                cls = cur.__class__.__name__.lower()
            try:
                name = str(cur.objectName()).lower()
            except Exception:
                name = ""

            sig = cls + " " + name
            if "canvas" in sig or "kisopengl" in sig:
                best = cur
                # prefer the deepest widget that actually has usable geometry
                try:
                    if cur.width() > 50 and cur.height() > 50:
                        return cur
                except Exception:
                    pass
            try:
                cur = cur.parent()
            except Exception:
                break
        return best

    def _candidate_widgets_at_global(self, gp, event_obj=None):
        """
        Collect visible QWidget geometries under the click without assuming
        Krita-internal canvas class names. Candidate geometry is NOT trusted
        until its Document.pixelData result independently matches Krita's
        real-canvas sampler RGB.
        """
        window = Krita.instance().activeWindow()
        qwindow = window.qwindow() if window else None
        if qwindow is None:
            return []

        candidates = []
        seen = set()

        def add_widget(w):
            if w is None:
                return
            try:
                key = int(w.winId()) if w.isWindow() else id(w)
            except Exception:
                key = id(w)
            if key in seen:
                return
            try:
                if not w.isVisible() or w.width() < 80 or w.height() < 80:
                    return
                lp = w.mapFromGlobal(gp)
                if not w.rect().contains(lp):
                    return
                # Never treat the ATLAS docker itself as canvas geometry.
                if w is self.widget() or self.widget().isAncestorOf(w):
                    return
            except Exception:
                return
            seen.add(key)
            candidates.append(w)

        # 1) actual widget under pointer + its ancestors
        try:
            cur = QApplication.widgetAt(gp)
        except Exception:
            cur = None
        if cur is None:
            cur = event_obj

        for _ in range(24):
            if cur is None:
                break
            add_widget(cur)
            if cur is qwindow:
                break
            try:
                cur = cur.parentWidget() if hasattr(cur, "parentWidget") else cur.parent()
            except Exception:
                break

        # 2) all visible descendants whose global rectangle contains click.
        # This catches OpenGL/viewport arrangements where the mouse event receiver
        # is not named "canvas" and is not the geometry we need.
        try:
            for w in qwindow.findChildren(QWidget):
                add_widget(w)
        except Exception:
            pass

        # Prefer smaller/deeper viewports for diagnostics/marker placement,
        # but source identity is never selected from this ordering.
        def area(w):
            try:
                return int(w.width()) * int(w.height())
            except Exception:
                return 10**18

        candidates.sort(key=area)
        return candidates

    def _document_gate(self, doc):
        model = str(doc.colorModel())
        depth = str(doc.colorDepth())
        profile = str(doc.colorProfile() or "")
        ok = model.upper() == "RGBA" and depth.upper() == "U8" and "srgb" in profile.lower()
        return ok, model, depth, profile

    def _widget_to_image_xy(self, canvas_api, canvas_widget, local_point):
        # Krita 6 exposes preferredCenter(): image pixel positioned at view center.
        if not hasattr(canvas_api, "preferredCenter"):
            raise RuntimeError(
                "Canvas.preferredCenter() is unavailable. Direct XY mode requires a Krita build "
                "that exposes this API."
            )

        rotation = float(canvas_api.rotation())
        mirrored = bool(canvas_api.mirror())
        if abs(rotation) > 1e-7 or mirrored:
            raise RuntimeError(
                "Direct XY v0.3.3 currently requires rotation = 0 and mirror = off. "
                "This is a deliberate fail-closed gate."
            )

        zoom = float(canvas_api.zoomLevel())
        if not math.isfinite(zoom) or zoom <= 0:
            raise RuntimeError("Invalid canvas zoom level: %r" % zoom)

        center = canvas_api.preferredCenter()
        cx = float(center.x())
        cy = float(center.y())

        widget_cx = canvas_widget.width() / 2.0
        widget_cy = canvas_widget.height() / 2.0

        # With rotation/mirror disabled:
        # screen displacement / zoom = image-pixel displacement.
        fx = cx + (float(local_point.x()) - widget_cx) / zoom
        fy = cy + (float(local_point.y()) - widget_cy) / zoom

        # Deterministic pixel cell containing the click.
        x = math.floor(fx)
        y = math.floor(fy)
        return x, y, fx, fy, zoom, cx, cy

    def _read_u8_rgba_projection_pixel(self, doc, x, y):
        raw = bytes(doc.pixelData(int(x), int(y), 1, 1))
        if len(raw) < 4:
            raise RuntimeError("Document.pixelData returned fewer than 4 bytes.")

        # Krita API: Integer RGBA pixelData channel order is Blue, Green, Red, Alpha.
        b, g, r, a = raw[0], raw[1], raw[2], raw[3]
        return (r, g, b, a), (b, g, r, a)

    def _read_sampler_rgb(self, view):
        color = view.foregroundColor() if hasattr(view, "foregroundColor") else view.foreGroundColor()
        comps = color.componentsOrdered()
        if len(comps) < 3:
            raise RuntimeError("Sampler foreground color has fewer than three components.")
        rgb = tuple(_norm_u8(v) for v in comps[:3])
        alpha = _norm_u8(comps[3]) if len(comps) >= 4 else 255
        return rgb, alpha

    def _set_source_summary(self, rgb=None, x=None, y=None, label="SOURCE PIXEL"):
        if rgb is None:
            self.source_swatch.setStyleSheet("background: transparent; border: 2px solid #666;")
            self.source_summary.setText(
                "<b>%s</b><br>XY —<br>RGB —<br>HEX —" % label
            )
            return

        r, g, b = rgb
        self.source_swatch.setStyleSheet(
            "background-color: rgb(%d,%d,%d); border: 3px solid #FFFFFF;" % (r, g, b)
        )
        xy = "—" if x is None or y is None else "%d, %d" % (x, y)
        self.source_summary.setText(
            "<b>%s</b><br>"
            "XY %s<br>"
            "RGB %d, %d, %d<br>"
            "HEX %s"
            % (label, xy, r, g, b, _hex_for(rgb))
        )

    def _set_pkl_summary(self, row=None, d2=None, frozen=False):
        if row is None:
            self.pkl_summary_swatch.setStyleSheet("background: transparent; border: 2px solid #666;")
            self.pkl_summary.setText(
                "<b>PKL REFERENCE</b><br>"
                "Reference —<br>"
                "atlas_row_id —<br>"
                "PKL RGB/HEX —<br>"
                "d²_RGB — · NOT_FROZEN"
            )
            return

        r, g, b = row["rgb"]
        self.pkl_summary_swatch.setStyleSheet(
            "background-color: rgb(%d,%d,%d); border: 4px solid #00D8FF;" % (r, g, b)
        )
        state = "FROZEN" if frozen else "BROWSE / NOT SOURCE-FROZEN"
        d2_txt = "—" if d2 is None else str(d2)
        self.pkl_summary.setText(
            "<b>PKL REFERENCE</b><br>"
            "%s<br>"
            "atlas_row_id %d<br>"
            "PKL %d, %d, %d · %s<br>"
            "d²_RGB %s · <b>%s</b>"
            % (
                row["reference"],
                row["atlas_row_id"],
                r, g, b, row["hex"],
                d2_txt,
                state,
            )
        )

    # ------------------------------------------------------
    # Picker
    # ------------------------------------------------------
    def arm_picker(self):
        window = Krita.instance().activeWindow()
        if not window or not window.activeView():
            QMessageBox.warning(self, "ATLAS Clarus PKL", "Open a Krita document/view first.")
            return

        view = window.activeView()
        doc = view.document()
        if doc is None:
            QMessageBox.warning(self, "ATLAS Clarus PKL", "No active document.")
            return

        ok, model, depth, profile = self._document_gate(doc)
        self.profile_label.setText(profile or "UNKNOWN")
        if not ok:
            self._picker_fail(
                "SOURCE_AUTHORITY = UNRESOLVED. Direct v3.4.0 freeze requires RGBA / U8 / "
                "documented sRGB; active document is %s / %s / %s."
                % (model, depth, profile or "UNKNOWN")
            )
            return

        canvas_api = view.canvas()
        if not hasattr(canvas_api, "preferredCenter"):
            self._picker_fail(
                "Direct XY unavailable: this Krita build does not expose Canvas.preferredCenter()."
            )
            return

        if abs(float(canvas_api.rotation())) > 1e-7 or bool(canvas_api.mirror()):
            self._picker_fail(
                "Direct XY v0.3.3 blocked: set canvas rotation to 0° and mirror off. "
                "The image itself is not modified."
            )
            return

        sampler_action = Krita.instance().action("sample_screen_color_real_canvas")
        if sampler_action is None:
            self._picker_fail(
                "Independent verification unavailable: Krita action "
                "'sample_screen_color_real_canvas' not found. No direct freeze performed."
            )
            return

        self._picker_armed = True
        self._pending_pick = {"view": view, "doc": doc, "canvas_api": canvas_api}
        self.pick_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.freeze_label.setText("NOT_FROZEN / PICKER_ARMED")
        self.picker_state.setText(
            "🟡 ARMED — click exactly one image pixel. Waiting for canvas mouse release…"
        )
        self.xy_label.setText("Document XY: pending")
        self.raw_label.setText("Raw pixelData BGRA: pending")
        self.crosscheck_label.setText("Independent sampler cross-check: pending")

        # Krita handles actual canvas color sampling; our event filter independently records the click.
        sampler_action.trigger()

    def cancel_picker(self):
        self._picker_armed = False
        self._pending_pick = None
        self.pick_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.picker_state.setText("Picker cancelled.")
        self.freeze_label.setText("NOT_FROZEN")

    def _handle_mouse_release(self, obj, event):
        if not self._picker_armed:
            return

        # Keep docker/UI clicks from being treated as image picks.
        try:
            if obj is self.widget() or self.widget().isAncestorOf(obj):
                return
        except Exception:
            pass

        pending = self._pending_pick
        if not pending:
            self._picker_fail("Internal picker state missing.")
            return

        gp = _global_pos(event)
        candidates = self._candidate_widgets_at_global(gp, obj)

        if not candidates:
            self.picker_state.setText(
                "🟡 ARMED — click captured but no usable view geometry found; try again."
            )
            return

        # Stop accepting further clicks while Krita finishes its own real-canvas sample.
        self._picker_armed = False
        self.pick_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)

        self._pending_pick = {
            "view": pending["view"],
            "doc": pending["doc"],
            "canvas_api": pending["canvas_api"],
            "global_x": int(gp.x()),
            "global_y": int(gp.y()),
            "global_point": gp,
            "candidate_widgets": candidates,
        }

        self.picker_state.setText(
            "🟦 CLICK CAPTURED — resolving exact document XY from %d candidate view geometries…"
            % len(candidates)
        )
        self.xy_label.setText("Document XY: resolving…")
        self.raw_label.setText("Raw pixelData BGRA: resolving…")
        self.crosscheck_label.setText("Independent sampler cross-check: resolving…")

        # Krita's sampler action receives the same click. Wait for foreground-color update,
        # then use that color ONLY to validate which QWidget geometry maps to the clicked
        # document coordinate. PKL identity still comes solely from Document.pixelData.
        QTimer.singleShot(140, self._resolve_canvas_geometry)

    def _resolve_canvas_geometry(self):
        p = self._pending_pick
        if not p or "candidate_widgets" not in p:
            self._picker_fail("Canvas-geometry resolution state missing.")
            return

        view = p["view"]
        doc = p["doc"]
        canvas_api = p["canvas_api"]
        gp = p["global_point"]

        try:
            sampler_rgb, sampler_alpha = self._read_sampler_rgb(view)
        except Exception as e:
            self._picker_fail("Independent real-canvas sampler read failed: %s" % e)
            return

        bounds = doc.bounds()
        matches_by_xy = {}
        attempted = 0

        for widget in p["candidate_widgets"]:
            try:
                local = widget.mapFromGlobal(gp)
                x, y, fx, fy, zoom, center_x, center_y = self._widget_to_image_xy(
                    canvas_api, widget, local
                )
                if not bounds.contains(int(x), int(y)):
                    continue

                rgba, bgra = self._read_u8_rgba_projection_pixel(doc, x, y)
                attempted += 1

                # Geometry cross-check only. The sampler is not the identity source.
                if tuple(rgba[:3]) != tuple(sampler_rgb):
                    continue

                xy_key = (int(x), int(y))
                record = {
                    "widget": widget,
                    "local": local,
                    "x": int(x),
                    "y": int(y),
                    "fx": float(fx),
                    "fy": float(fy),
                    "zoom": float(zoom),
                    "preferred_center": (float(center_x), float(center_y)),
                    "rgba": rgba,
                    "bgra": bgra,
                }

                # Multiple nested widgets may have identical geometry and therefore
                # resolve to the same document XY. Keep the smallest-area widget
                # only for marker placement; the source pixel is identical.
                if xy_key not in matches_by_xy:
                    matches_by_xy[xy_key] = record
                else:
                    old = matches_by_xy[xy_key]
                    try:
                        old_area = old["widget"].width() * old["widget"].height()
                        new_area = widget.width() * widget.height()
                        if new_area < old_area:
                            matches_by_xy[xy_key] = record
                    except Exception:
                        pass
            except Exception:
                continue

        if len(matches_by_xy) == 0:
            self.freeze_label.setText("NOT_FROZEN / CANVAS_GEOMETRY_UNRESOLVED")
            self.summary_gate.setText(
                "<b>CANVAS GEOMETRY CROSSCHECK = FAIL</b> · FREEZE_STATUS = NOT_FROZEN_EXPERIMENTAL"
            )
            self.picker_state.setText(
                "🔴 NOT FROZEN — click was captured, but none of %d tested view geometries "
                "mapped Document.pixelData to sampler RGB %s."
                % (attempted, _hex_for(sampler_rgb))
            )
            self.status.setText(
                "DIRECT XY geometry unresolved · source_atlas_row_id NOT FROZEN · "
                "sampler used only as geometry cross-check."
            )
            return

        if len(matches_by_xy) > 1:
            coords = sorted(matches_by_xy.keys())
            preview = ", ".join("(%d,%d)" % xy for xy in coords[:5])
            self.freeze_label.setText("NOT_FROZEN / AMBIGUOUS_CANVAS_GEOMETRY")
            self.summary_gate.setText(
                "<b>CANVAS GEOMETRY = AMBIGUOUS</b> · FREEZE_STATUS = NOT_FROZEN_EXPERIMENTAL"
            )
            self.picker_state.setText(
                "🔴 NOT FROZEN — multiple document coordinates match sampler RGB %s: %s%s"
                % (
                    _hex_for(sampler_rgb),
                    preview,
                    " …" if len(coords) > 5 else "",
                )
            )
            self.status.setText(
                "AMBIGUOUS_CANVAS_GEOMETRY · no source identity frozen."
            )
            return

        # Exactly one document XY survived independent sampler verification.
        record = next(iter(matches_by_xy.values()))
        widget = record["widget"]
        local = record["local"]

        self._pending_pick = {
            "view": view,
            "doc": doc,
            "canvas_api": canvas_api,
            "canvas_widget": widget,
            "local_x": int(local.x()),
            "local_y": int(local.y()),
            "x": record["x"],
            "y": record["y"],
            "fx": record["fx"],
            "fy": record["fy"],
            "zoom": record["zoom"],
            "preferred_center": record["preferred_center"],
            "rgba": record["rgba"],
            "bgra": record["bgra"],
            "sampler_rgb_verified": tuple(sampler_rgb),
            "sampler_alpha_verified": int(sampler_alpha),
        }

        rgba = record["rgba"]
        bgra = record["bgra"]
        x = record["x"]
        y = record["y"]

        self._set_source_summary(tuple(rgba[:3]), x, y)
        self.xy_label.setText(
            "Document XY: (%d, %d)  |  float=(%.4f, %.4f)  |  zoom=%.6f"
            % (x, y, record["fx"], record["fy"], record["zoom"])
        )
        self.raw_label.setText(
            "Raw pixelData BGRA: %d,%d,%d,%d  → RGBA: %d,%d,%d,%d"
            % (
                bgra[0], bgra[1], bgra[2], bgra[3],
                rgba[0], rgba[1], rgba[2], rgba[3],
            )
        )
        self.crosscheck_label.setText(
            "✅ GEOMETRY PASS — unique XY (%d,%d); raw RGB %s == real-canvas sampler RGB %s"
            % (x, y, _hex_for(tuple(rgba[:3])), _hex_for(tuple(sampler_rgb)))
        )
        self.picker_state.setText(
            "🟦 UNIQUE DOCUMENT XY RESOLVED — performing PKL freeze…"
        )

        self._show_click_marker(widget, int(local.x()), int(local.y()))
        QTimer.singleShot(0, self._finalize_direct_pick)

    def _finalize_direct_pick(self):
        p = self._pending_pick
        if not p or "rgba" not in p:
            self._picker_fail("Pending raw pixel vanished before verification.")
            return

        view = p["view"]
        if "sampler_rgb_verified" in p:
            sampler_rgb = tuple(p["sampler_rgb_verified"])
            sampler_alpha = int(p.get("sampler_alpha_verified", 255))
        else:
            try:
                sampler_rgb, sampler_alpha = self._read_sampler_rgb(view)
            except Exception as e:
                self._picker_fail("Independent sampler read failed: %s" % e)
                return

        raw_rgb = tuple(p["rgba"][:3])
        raw_alpha = int(p["rgba"][3])

        if sampler_rgb != raw_rgb:
            self.crosscheck_label.setText(
                "❌ FAIL — raw RGB %s vs real-canvas sampler RGB %s"
                % (_hex_for(raw_rgb), _hex_for(sampler_rgb))
            )
            self.summary_gate.setText(
                "<b>RAW/SAMPLER CROSSCHECK = FAIL</b> · FREEZE_STATUS = NOT_FROZEN_EXPERIMENTAL"
            )
            self._set_pkl_summary(None)
            self.freeze_label.setText("NOT_FROZEN / XY_CROSSCHECK_FAIL")
            self.status.setText(
                "DIRECT PIXEL READ COMPLETED but coordinate/source cross-check failed. "
                "No PKL source identity frozen."
            )
            self.picker_state.setText(
                "🔴 NOT FROZEN — Document.pixelData and Krita real-canvas sampler disagree."
            )
            return

        self.crosscheck_label.setText(
            "✅ PASS — raw RGB %s == real-canvas sampler RGB %s"
            % (_hex_for(raw_rgb), _hex_for(sampler_rgb))
        )
        self.summary_gate.setText(
            "<b>RAW/SAMPLER CROSSCHECK = PASS</b> · measured_qc_status = NOT_MEASURED"
        )
        self._set_source_summary(raw_rgb, p["x"], p["y"])

        # Alpha is recorded but does not alter the RGB-only reference-distance metric.
        row, d2 = self.engine.nearest_rgb(raw_rgb)
        self._last_input_rgb = raw_rgb
        self._show_row(
            row,
            d2=d2,
            freeze=True,
            input_rgb=raw_rgb,
            freeze_label="FROZEN / DIRECT PIXELDATA",
            profile=str(p["doc"].colorProfile() or ""),
        )
        self._set_pkl_summary(row, d2=d2, frozen=True)

        self.freeze_label.setText("FROZEN / DIRECT PIXELDATA")
        self.picker_state.setText(
            "🟢 DIRECT FREEZE — XY (%d,%d) → %s → %s / row %d"
            % (p["x"], p["y"], _hex_for(raw_rgb), row["reference"], row["atlas_row_id"])
        )
        self.status.setText(
            "Recognised input: Document.pixelData(%d,%d,1,1) RGBA/U8/sRGB · "
            "raw/sampler cross-check PASS · source_atlas_row_id FROZEN · "
            "Mode RGB_ONLY_DLambda_POSTHOC · production_atlas_row_id = source_atlas_row_id · "
            "alpha=%d · measured_qc_status = NOT_MEASURED"
            % (p["x"], p["y"], raw_alpha)
        )

        self.highlight_reference()

    def _picker_fail(self, reason):
        self._picker_armed = False
        self._pending_pick = None
        self.pick_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.freeze_label.setText("NOT_FROZEN_EXPERIMENTAL")
        self.summary_gate.setText(
            "<b>FREEZE_STATUS = NOT_FROZEN_EXPERIMENTAL</b> · direct pixel gate failed"
        )
        self.picker_state.setText("🔴 " + reason)
        self.status.setText(
            "SOURCE_AUTHORITY = UNRESOLVED or direct-coordinate gate failed · "
            "FREEZE_STATUS = NOT_FROZEN_EXPERIMENTAL"
        )

    def _show_click_marker(self, canvas_widget, x, y):
        try:
            if self._marker is not None:
                self._marker.deleteLater()
        except Exception:
            pass

        marker = QFrame(canvas_widget)
        marker.setAttribute(WA_TRANSPARENT_MOUSE, True)
        marker.setFixedSize(24, 24)
        marker.move(int(x - 12), int(y - 12))
        marker.setStyleSheet(
            "background: transparent; border: 3px solid #FFD400; border-radius: 12px;"
        )
        marker.raise_()
        marker.show()
        self._marker = marker

        def hide_marker():
            try:
                marker.hide()
                marker.deleteLater()
            except Exception:
                pass
            if self._marker is marker:
                self._marker = None

        QTimer.singleShot(2200, hide_marker)

    # ------------------------------------------------------
    # Explicit lookup + browsing
    # ------------------------------------------------------
    def refresh_search(self):
        rows = self.engine.search(self.search_edit.text())
        self.list_widget.blockSignals(True)
        self.list_widget.clear()
        for row in rows:
            item = QListWidgetItem(
                "%s · row %d · %s" %
                (row["reference"], row["atlas_row_id"], row["hex"])
            )
            item.setData(USER_ROLE, row)
            self.list_widget.addItem(item)
        self.list_widget.blockSignals(False)

        if self.search_edit.text().strip():
            self.search_count_label.setText(
                "Matches: %d / %d master rows" % (len(rows), len(self.engine.rows))
            )
        else:
            self.search_count_label.setText(
                "Full PKL master: %d rows" % len(self.engine.rows)
            )

    def search_selection_changed(self):
        items = self.list_widget.selectedItems()
        if not items:
            return
        self._last_input_rgb = None
        self._set_source_summary(None)
        row = items[0].data(USER_ROLE)
        self._show_row(row, d2=None, freeze=False)
        self._set_pkl_summary(row, d2=None, frozen=False)
        self.summary_gate.setText(
            "DIRECT BROWSE ONLY · no source identity frozen · measured_qc_status = NOT_MEASURED"
        )

    def match_input(self):
        try:
            rgb = _parse_rgb_or_hex(self.input_edit.text())
        except ValueError as e:
            QMessageBox.warning(self, "ATLAS Clarus PKL", str(e))
            return

        row, d2 = self.engine.nearest_rgb(rgb)
        self._last_input_rgb = rgb
        self._set_source_summary(rgb, None, None, label="EXPLICIT sRGB")
        self.summary_gate.setText(
            "Explicit documented 8-bit sRGB input · measured_qc_status = NOT_MEASURED"
        )
        self._show_row(
            row,
            d2=d2,
            freeze=True,
            input_rgb=rgb,
            freeze_label="FROZEN / EXPLICIT sRGB",
            profile="documented 8-bit sRGB input",
        )
        self._set_pkl_summary(row, d2=d2, frozen=True)
        self.status.setText(
            "Recognised input: documented 8-bit sRGB %s · source_atlas_row_id FROZEN · "
            "RGB_ONLY_DLambda_POSTHOC · measured_qc_status = NOT_MEASURED"
            % _hex_for(rgb)
        )

    def _show_row(
        self,
        row,
        d2=None,
        freeze=False,
        input_rgb=None,
        freeze_label=None,
        profile=None,
    ):
        self._selected = row
        r, g, b = row["rgb"]

        # Exact digital PKL swatch from bundled active-master RGB.
        self.swatch.setStyleSheet(
            "background-color: rgb(%d,%d,%d); border: 3px solid #00D8FF;" % (r, g, b)
        )

        self.ref_label.setText(row["reference"])
        self.id_label.setText(str(row["atlas_row_id"]))
        self.src_label.setText("—" if input_rgb is None else "%d, %d, %d" % input_rgb)
        self.rgb_label.setText("%d, %d, %d" % (r, g, b))
        self.hex_label.setText(row["hex"])
        self.d2_label.setText("—" if d2 is None else str(d2))

        lab = row["lab"]
        self.lab_label.setText("%.2f, %.2f, %.2f" % (lab[0], lab[1], lab[2]))

        dl = row.get("delta_lambda_nm")
        self.dl_label.setText("—" if dl is None else "%.4f nm" % dl)
        self.oog_label.setText("YES" if row.get("srgb_out_of_gamut_before_clip") else "NO")

        if profile is not None:
            self.profile_label.setText(profile)

        self.freeze_label.setText(
            freeze_label if freeze else "DIRECT BROWSE / NOT SOURCE-FROZEN"
        )
        self.use_btn.setEnabled(True)
        self.highlight_btn.setEnabled(True)

    # ------------------------------------------------------
    # Actions
    # ------------------------------------------------------
    def use_selected_color(self):
        if not self._selected:
            return

        window = Krita.instance().activeWindow()
        if not window or not window.activeView():
            QMessageBox.warning(
                self, "ATLAS Clarus PKL",
                "Open a document/view in Krita before applying a PKL colour."
            )
            return

        view = window.activeView()
        r, g, b = self._selected["rgb"]
        managed = ManagedColor.fromQColor(QColor(r, g, b), view.canvas())
        view.setForeGroundColor(managed)

        self.status.setText(
            "Applied exact PKL sRGB reference %s / row %d to Krita foreground. "
            "Canvas conversion is downstream; frozen identity is unchanged."
            % (self._selected["reference"], self._selected["atlas_row_id"])
        )

    def highlight_reference(self):
        if not self._selected:
            return

        r, g, b = self._selected["rgb"]
        self.swatch.setStyleSheet(
            "background-color: rgb(%d,%d,%d); border: 6px solid #FFD400;" % (r, g, b)
        )
        QTimer.singleShot(900, self._restore_swatch_border)

        window = Krita.instance().activeWindow()
        view = window.activeView() if window else None
        if view:
            msg = "ATLAS PKL  %s  |  row %d  |  %s" % (
                self._selected["reference"],
                self._selected["atlas_row_id"],
                self._selected["hex"],
            )
            try:
                view.showFloatingMessage(msg, QIcon(), 2800, 1)
            except Exception:
                pass

    def _restore_swatch_border(self):
        if not self._selected:
            return
        r, g, b = self._selected["rgb"]
        self.swatch.setStyleSheet(
            "background-color: rgb(%d,%d,%d); border: 3px solid #00D8FF;" % (r, g, b)
        )


Krita.instance().addDockWidgetFactory(
    DockWidgetFactory(
        DOCKER_ID,
        DockWidgetFactoryBase.DockRight,
        AtlasClarusDocker
    )
)
