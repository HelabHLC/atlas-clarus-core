# ATLAS Clarus × Krita v0.3.4 — Frozen Release

Contents:
- `01_EXTENSION/`: recovered exact v0.3.4 release ZIP plus unpacked release
- `02_RUNTIME_EVIDENCE/`: screenshots from the executed Krita runtime gates
- `03_DOCUMENTATION/`: validation report and known limitations
- `MANIFEST.json`: machine-readable freeze record
- `SHA256SUMS.txt`: hashes of all frozen files except itself

Freeze rule: do not modify v0.3.4 in place. Develop subsequent changes under a new version.
