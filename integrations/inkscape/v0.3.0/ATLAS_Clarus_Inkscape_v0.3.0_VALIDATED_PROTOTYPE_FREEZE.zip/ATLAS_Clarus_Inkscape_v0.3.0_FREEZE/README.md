# ATLAS Clarus Inkscape v0.3.0 — Frozen Release Package

This archive freezes the first validated ATLAS Clarus Inkscape prototype baseline.

## Contents
- `01_EXTENSION/` — exact v0.3.0 extension package and unpacked files
- `02_VALIDATION_FIXTURES/` — source, failed intermediate, validated v0.2.2 and validated v0.3.0 saved SVGs
- `03_VALIDATION_EVIDENCE/` — earlier four-gate SVG stress-test artifacts
- `04_DOCUMENTATION/` — validation report and known limitations
- `MANIFEST.json` — machine-readable release/validation metadata
- `SHA256SUMS.txt` — SHA-256 for every frozen file except itself

## Freeze rule
Do not silently modify v0.3.0. New development belongs to v0.4.x and should be regression-tested against this baseline.
