# Known Limitations — ATLAS Clarus Inkscape v0.3.0

1. **Validated scope is narrow.** The release is validated for the tested SVG/CSS `#RRGGBB` fill/stroke path, including the Rautentest CSS stroke case.
2. **Gradient stops are not modified by v0.3.0.** Earlier SVG stress testing demonstrated persistence of defined gradient stop values, but the v0.3.0 extension does not bind gradient stops.
3. **Embedded raster pixels are not modified by v0.3.0.** Earlier stress testing preserved an embedded exact-PKL raster, but raster conversion is outside the extension's current mutation scope.
4. **Opacity is not modified.** Colour identity and opacity remain separate.
5. **Non-hex colour syntax is not covered.** Named colours, `rgb()`, `rgba()`, CSS variables, advanced selectors/cascade cases and other syntaxes are not validated by this release.
6. **Direct object binding requires selection.** Direct `fill`/`stroke` values are processed on selected objects; document-level CSS style declarations are processed separately.
7. **No Lab, Delta E or ICC is used for source identity selection.**
8. **No physical colour or print validation is implied.** `MEASURED_QC = NOT_MEASURED`.
9. **No universal Inkscape claim.** `INKSCAPE_RUNTIME = PASS` refers to the recorded tested workflow, not all Inkscape versions, platforms or document structures.
10. **Reference packaging.** The release contains the exact compact JSON reference representation bundled with the extension. Upstream reference provenance/licensing remains a separate governance concern.
