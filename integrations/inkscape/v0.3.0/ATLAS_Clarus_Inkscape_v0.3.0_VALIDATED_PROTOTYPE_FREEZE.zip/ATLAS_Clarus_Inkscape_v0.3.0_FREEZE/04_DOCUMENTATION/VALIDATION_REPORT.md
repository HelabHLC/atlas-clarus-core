# ATLAS Clarus Inkscape v0.3.0 — Validation Report

**Release class:** VALIDATED PROTOTYPE BASELINE  
**Freeze status:** FROZEN  
**Freeze date:** 2026-08-23

## Validated path

The v0.3.0 runtime smoke test used the Rautentest SVG CSS stroke:

`Source #00349C → HLC H285_L025_C065 → PKL #00379D → atlas_row_id 10519 | d2_RGB = 10`

The Inkscape extension reported one bound CSS colour declaration. The file was then saved from Inkscape and returned for audit.

## Final saved-SVG audit

- Active CSS target `stroke:#00379D`: 1
- Active CSS source `stroke:#00349C`: 0
- `data-atlas-clarus-extension`: `0.3.0`
- `data-atlas-clarus-method`: `RGB_ONLY_INTEGER_D2`
- `data-atlas-clarus-tiebreak`: `SMALLER_ATLAS_ROW_ID`
- `data-atlas-clarus-k`: `UNLIMITED`
- CSS records: `1`

## Gate status

- EXTENSION_EXECUTION = PASS
- CSS_DETECTION = PASS
- RGB_ONLY_BINDING = PASS
- HLC_PKL_ROW_OUTPUT = PASS
- AUDIT_METADATA_PERSISTENCE = PASS
- SAVED_SVG_PERSISTENCE = PASS
- INKSCAPE_RUNTIME = PASS
- MEASURED_QC = NOT_MEASURED

## Interpretation

This validates the tested SVG/CSS colour-binding path in a real Inkscape runtime and save roundtrip. It does **not** establish universal compatibility with every Inkscape colour representation, SVG feature, renderer, export format, device profile, or physical print condition.

The frozen v0.3.0 package is the regression baseline for future v0.4.x development.
