ATLAS Clarus Inkscape Extension v0.3.0

PRODUCTION-BETA SCOPE
- Direct fill/stroke #RRGGBB on selected SVG objects
- CSS <style> fill/stroke #RRGGBB declarations
- Deterministic RGB-only ATLAS binding
- Integer squared RGB distance
- Exact tie: smaller atlas_row_id
- K = UNLIMITED
- No Lab, Delta E or ICC in identity selection
- Persistent audit metadata in the SVG
- Human-readable Inkscape output:
  Source -> HLC -> PKL -> atlas_row_id

INSTALL
1. Remove/disable older ATLAS Clarus v0.2.x extension folders.
2. In Inkscape: Edit > Preferences > System > User extensions.
3. Copy atlas-clarus-inkscape-v0.3.0 into that directory.
4. Restart Inkscape.
5. Open an SVG.
6. For direct object colours, select the objects to bind.
7. Run Extensions > Color > ATLAS Clarus · Bind Colours v0.3.0.
8. Save As a NEW SVG for audit.

NOT YET MODIFIED BY v0.3.0
- gradient stop colours
- embedded raster pixels
- non-hex CSS colour syntaxes
- opacity values

Note: CSS <style> declarations are document-level and are processed even when no object is selected.
