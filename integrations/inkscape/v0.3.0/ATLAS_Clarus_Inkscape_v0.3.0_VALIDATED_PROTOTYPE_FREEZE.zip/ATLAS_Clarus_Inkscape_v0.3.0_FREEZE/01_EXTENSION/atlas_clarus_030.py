#!/usr/bin/env python3
import os,re,json,inkex

MASTER_FILE="atlas_master_compact.json"
DECL_RE=re.compile(r"(?P<prop>fill|stroke)\s*:\s*(?P<hex>#[0-9A-Fa-f]{6})(?P<important>\s*!important)?",re.I)
HEX_RE=re.compile(r"^#[0-9A-Fa-f]{6}$")

def h2rgb(h):
    h=h.lstrip("#"); return tuple(int(h[i:i+2],16) for i in (0,2,4))
def rgb2h(v): return "#{:02X}{:02X}{:02X}".format(*v)

class AtlasClarus030(inkex.EffectExtension):
    def load_master(self):
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),MASTER_FILE),"r",encoding="utf-8") as f:
            rows=json.load(f)
        rows.sort(key=lambda r:int(r["atlas_row_id"]))
        return rows

    @staticmethod
    def nearest(q,rows):
        return min(rows,key=lambda r:(sum((a-b)**2 for a,b in zip(q,r["rgb"])),int(r["atlas_row_id"])))

    def bind(self,h,rows):
        q=h2rgb(h); row=self.nearest(q,rows)
        d2=sum((a-b)**2 for a,b in zip(q,row["rgb"]))
        return row,d2,rgb2h(tuple(row["rgb"]))

    def audit_element(self,e,source,target,row,d2,prop):
        e.set("data-atlas-clarus-version","0.3.0")
        e.set("data-atlas-source-"+prop,source.upper())
        e.set("data-atlas-target-"+prop,target.upper())
        e.set("data-atlas-ref-"+prop,str(row["reference"]))
        e.set("data-atlas-row-id-"+prop,str(row["atlas_row_id"]))
        e.set("data-atlas-d2-rgb-"+prop,str(d2))

    def effect(self):
        rows=self.load_master(); records=[]

        # 1) Direct selected object styles: fill/stroke.
        for e in list(self.svg.selection):
            for prop in ("fill","stroke"):
                val=e.style.get(prop)
                if not val or not HEX_RE.match(str(val).strip()): continue
                source=str(val).strip().upper()
                row,d2,target=self.bind(source,rows)
                e.style[prop]=target
                self.audit_element(e,source,target,row,d2,prop)
                records.append(("DIRECT",e.get("id","(no-id)"),prop,source,target,row["reference"],row["atlas_row_id"],d2))

        # 2) CSS <style> blocks. This is the runtime-proven v0.2.2 mechanism.
        css_count=0
        for sidx,node in enumerate(self.svg.xpath("//*[local-name()='style']")):
            css=node.text or ""
            def repl(m):
                nonlocal css_count
                prop=m.group("prop").lower(); source=m.group("hex").upper()
                row,d2,target=self.bind(source,rows)
                css_count += 1
                records.append(("CSS","style[{}]".format(sidx),prop,source,target,row["reference"],row["atlas_row_id"],d2))
                return "{}: {}{}".format(prop,target,m.group("important") or "")
            node.text=DECL_RE.sub(repl,css)

        # Root audit summary survives Inkscape Save As.
        self.svg.set("data-atlas-clarus-extension","0.3.0")
        self.svg.set("data-atlas-clarus-records",str(len(records)))
        self.svg.set("data-atlas-clarus-direct-records",str(sum(1 for r in records if r[0]=="DIRECT")))
        self.svg.set("data-atlas-clarus-css-records",str(css_count))
        self.svg.set("data-atlas-clarus-method","RGB_ONLY_INTEGER_D2")
        self.svg.set("data-atlas-clarus-tiebreak","SMALLER_ATLAS_ROW_ID")
        self.svg.set("data-atlas-clarus-k","UNLIMITED")

        inkex.errormsg("ATLAS Clarus v0.3.0")
        if not records:
            inkex.errormsg("No eligible #RRGGBB fill/stroke colours found.")
            return
        inkex.errormsg("Bound colour declarations: {}".format(len(records)))
        inkex.errormsg("")
        for kind,obj,prop,src,dst,ref,rid,d2 in records[:60]:
            inkex.errormsg("{} | {} | {}".format(kind,obj,prop))
            inkex.errormsg("  Source {} -> HLC {} -> PKL {} -> atlas_row_id {} | d2_RGB={}".format(
                src,ref,dst,rid,d2))
        if len(records)>60:
            inkex.errormsg("... {} additional records".format(len(records)-60))

if __name__=="__main__":
    AtlasClarus030().run()
